export class Player{
    id:number;
    name: string;
    image:any;
    country:string;
    totruns:number;
    totwickets:number
}